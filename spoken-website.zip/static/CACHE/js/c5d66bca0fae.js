$(document).ready(function(){currentVideo=$('.playlist-item.active');nextVideo=currentVideo.next('li');prevVideo=currentVideo.prev('li');var tmpHtml=currentVideo.attr('data')+'/'+$('.video-count').html()
$('.video-count').html(tmpHtml)
if(nextVideo.length){$('.forward').html('<a href="'+nextVideo.children('a').attr('href')+'"><i class="fa fa-1 fa-fast-forward"></i></a>');}else{$('.forward').html('<i class="fa fa-1 fa-fast-forward"></i>');}
if(prevVideo.length){$('.backward').html('<a href="'+prevVideo.children('a').attr('href')+'"><i class="fa fa-1 fa-fast-backward"></i></a>');}else{$('.backward').html('<i class="fa fa-1 fa-fast-backward"></i>');}
$(".fancybox").fancybox({maxWidth:500,maxHeight:485,fitToView:true,autoSize:false,closeClick:false,openEffect:"none",closeEffect:"none",modal:true,});$(".video-show-more").click(function(e){e.preventDefault();$(".video-info").slideToggle("slow");$(this).text($(this).text()=='Show video info'?"Hide video info":"Show video info");});});var player,tag=document.createElement('script'),firstScriptTag=document.getElementsByTagName('script')[0];var flag=false;tag.src="https://www.youtube.com/iframe_api";firstScriptTag.parentNode.insertBefore(tag,firstScriptTag);function onPlaybackQualityChange(event){console.log(event);}
Number.prototype.between=function(min,max){return this>=min&&this<=max;};var ik_player;function onYouTubeIframeAPIReady(){ik_player=new YT.Player('player');ik_player.addEventListener("onReady","onReady");ik_player.addEventListener("onStateChange","onStateChange");}
function formatTime(time){time=Math.round(time);var minutes=Math.floor(time/60),seconds=time-minutes*60;seconds=seconds<10?'0'+seconds:seconds;return minutes+"."+seconds;}
function onReady(event){function logDuration(){window.setTimeout(logDuration,1000);var cur_time=formatTime(ik_player.getCurrentTime()).toString();var duration=formatTime(ik_player.getDuration()).toString();if(parseFloat(cur_time)==parseFloat(duration.toString())){$('.ScrollStyle').find('.question').css("background-color","white");}else{trigger(cur_time,duration);}
return cur_time}
logDuration();$("#text").click(function(e){ik_player.pauseVideo()
setForum(logDuration())});}
function trigger(cur_time,duration){}
var trackedPlayer=videojs('st_video');var previousTime=0;var currentTime=0;trackedPlayer.on('timeupdate',function(){previousTime=currentTime;currentTime=trackedPlayer.currentTime();var cur_time=formatTime(currentTime).toString();trigger(cur_time);$("#text").click(function(e){trackedPlayer.pause()
setForum(cur_time)});});function setForum(cur_time)
{var time_split=cur_time.split(".")
var minute=parseFloat(time_split[0]);var min_range=minute+"-"+(minute+parseFloat(1))
if(parseInt(time_split[1]).between(parseInt(0),parseInt(9))){sec_range="0-10"}else if(parseFloat(time_split[1]).between(parseFloat(10),parseFloat(19))){sec_range="10-20"}else if(parseFloat(time_split[1]).between(parseFloat(20),parseFloat(29))){sec_range="20-30"}else if(parseFloat(time_split[1]).between(parseFloat(30),parseFloat(39))){sec_range="30-40"}else if(parseFloat(time_split[1]).between(parseFloat(40),parseFloat(49))){sec_range="40-50"}else{sec_range="50-60"}
var url="http://forums.spoken-tutorial.org/new-question/?category=ASCEND&tutorial=Solving Cubic EOS&minute_range="+min_range+"&second_range="+sec_range;$("#text").attr("href",url);}