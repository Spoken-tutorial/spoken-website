var $ = django.jQuery;
$(document).ready(function(){
    alert('Hello World');
});